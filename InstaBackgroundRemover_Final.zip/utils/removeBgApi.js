import axios from 'axios';
import { Platform } from 'react-native';

export const removeBackground = async (imageUri) => {
  const formData = new FormData();
  formData.append('image_file', {
    uri: Platform.OS === 'ios' ? imageUri.replace('file://', '') : imageUri,
    type: 'image/jpeg',
    name: 'photo.jpg',
  });

  const response = await axios.post('https://api.remove.bg/v1.0/removebg', formData, {
    headers: {
      'X-Api-Key': 'YOUR_REMOVE_BG_API_KEY',
      'Content-Type': 'multipart/form-data',
    },
    responseType: 'arraybuffer',
  });

  const base64 = `data:image/png;base64,${Buffer.from(response.data, 'binary').toString('base64')}`;
  return base64;
};