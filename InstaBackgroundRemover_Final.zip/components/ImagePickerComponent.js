import React, { useState } from 'react';
import { View, Button, Image, StyleSheet } from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';

const ImagePickerComponent = ({ onImageSelected }) => {
  const [imageUri, setImageUri] = useState(null);

  const pickImage = () => {
    launchImageLibrary({ mediaType: 'photo' }, (response) => {
      if (response.assets?.length > 0) {
        const uri = response.assets[0].uri;
        setImageUri(uri);
        onImageSelected(uri);
      }
    });
  };

  return (
    <View style={styles.container}>
      <Button title="Pick an Image" onPress={pickImage} />
      {imageUri && <Image source={{ uri: imageUri }} style={styles.image} />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { marginVertical: 20, alignItems: 'center' },
  image: { width: 200, height: 200, marginTop: 10 },
});

export default ImagePickerComponent;