import React from 'react';
import { View, Image, StyleSheet } from 'react-native';

const ResultView = ({ image }) => {
  return (
    <View style={styles.container}>
      <Image source={{ uri: image }} style={styles.image} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { alignItems: 'center', marginVertical: 20 },
  image: { width: 200, height: 200, backgroundColor: '#ddd' },
});

export default ResultView;