import React, { useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, SafeAreaView } from 'react-native';
import ImagePickerComponent from './components/ImagePickerComponent';
import ResultView from './components/ResultView';
import { removeBackground } from './utils/removeBgApi';

const App = () => {
  const [loading, setLoading] = useState(false);
  const [resultImage, setResultImage] = useState(null);

  const handleImage = async (uri) => {
    setLoading(true);
    try {
      const bgRemoved = await removeBackground(uri);
      setResultImage(bgRemoved);
    } catch (error) {
      console.error('Background removal failed:', error);
    }
    setLoading(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>InstaBackground Remover</Text>
      <ImagePickerComponent onImageSelected={handleImage} />
      {loading && <ActivityIndicator size="large" color="#0000ff" />}
      {resultImage && <ResultView image={resultImage} />}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 24, textAlign: 'center', marginVertical: 10 },
});

export default App;